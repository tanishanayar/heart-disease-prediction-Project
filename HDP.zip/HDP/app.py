from flask import Flask, render_template, request
import numpy as np
import pickle
import mysql.connector


app = Flask(__name__)

# Load ML model (make sure model.pkl is in the same directory)
model = pickle.load(open('model.pkl', 'rb'))

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root@123",
    database="heart_disease_db"
)
cursor = db.cursor()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict')
def predict():
    return render_template('form.html')

@app.route('/innerpage')
def innerpage():
    return render_template('innerpage.html')


@app.route('/submit_form', methods=['POST'])
def submit_form():
    try:
        # Get data from form and convert to float
        features = [
            float(request.form['age']),
            float(request.form['sex']),
            float(request.form['cp']),
            float(request.form['trestbps']),
            float(request.form['chol']),
            float(request.form['fbs']),
            float(request.form['restecg']),
            float(request.form['thalach']),
            float(request.form['exang']),
            float(request.form['oldpeak']),
            float(request.form['slope']),
            float(request.form['ca']),
            float(request.form['thal']),
        ]

        final_input = np.array([features])
        prediction = model.predict(final_input)[0]

        # You can customize message
        result_msg = "🔴 High risk of heart disease!" if prediction == 1 else "🟢 Low risk of heart disease."

        insert_query = """
        INSERT INTO predictions 
        (age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal, result)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (*features, result_msg))
        db.commit()

        return render_template('result.html', prediction=result_msg)

    except Exception as e:
        return f"Error: {str(e)}"



if __name__ == '__main__':
    app.run(debug=True)
